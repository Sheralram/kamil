import { Component, OnInit, ViewChild, ElementRef,ViewEncapsulation } from '@angular/core';
import { EChartsOption } from 'echarts';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LandingPageComponent implements OnInit {

  //@ViewChild("mymodal") mymodal: ElementRef;
  public dashboardSliderData: Array<any> = [];
  selectTab:string = "Summary";

  chartOption: EChartsOption = {
    xAxis: {
      type: 'category',
      data: ['District 1', 'District 2', 'District 3', 'District 4', 'District 5', 'District 6', 'District 7'],
    },
    yAxis: {
      type: 'value',
    },
    series: [
      {
        data: [10, 20, 30, 40, 50, 60, 70],
        type: 'bar',
      },
    ],
  };
  chartOption2: EChartsOption = {
    xAxis: {
      type: 'category',
      data: ['District 1', 'District 2', 'District 3', 'District 4', 'District 5', 'District 6', 'District 7'],
    },
    yAxis: {
      type: 'value',
    },
    series: [
      {
        data: [10, 50, 70, 40, 20, 30, 60],
        type: 'bar',
      },
    ],
  };
  chartOption3: EChartsOption = {
    xAxis: {
      type: 'category',
      data: ['District 1', 'District 2', 'District 3', 'District 4', 'District 5', 'District 6', 'District 7'],
    },
    yAxis: {
      type: 'value',
    },
    series: [
      {
        data: [50, 10, 20, 40, 70, 30, 60],
        type: 'bar',
      },
    ],
  };

  chartOption4: EChartsOption = {
    xAxis: {
      type: 'category',
      data: ['District 1', 'District 2', 'District 3', 'District 4', 'District 5', 'District 6', 'District 7'],
    },
    yAxis: {
      type: 'value',
    },
    series: [
      {
        data: [10, 50, 70, 40, 20, 30, 60],
        type: 'line',
      },
    ],
  };

  chartOption5: EChartsOption = {
    xAxis: {
      type: 'category',
      data: ['District 1', 'District 2', 'District 3', 'District 4', 'District 5', 'District 6', 'District 7'],
    },
    yAxis: {
      type: 'value',
    },
    series: [
      {
        data: [50, 10, 20, 40, 70, 30, 60],
        type: 'line',
      },
    ],
  };
  public closeResult: any;

  districtList: any = [];
  districtSelectedItems : any = [];
  dropdownSettings:IDropdownSettings = {};

  storeList: any = [];
  storeSelectedItems : any = [];

  cardlist: any =[{
    "categoryName": "Total Meeting",
    "value": "100",
  }, {
    "categoryName": "Avg Meeting Time",
    "value": "35 min",
  }, {
    "categoryName": "Total Transactions",
    "value": "2,335",
    
  },{
    "categoryName": "Total Amount",
    "value": "2,54,335",
  },{
    "categoryName": "$ per Transactions",
    "value": "60",
  }];
  constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
		this.dashboardSliderData = [{
			"categoryName": "Total Meeting",
			"value": "100",
		}, {
			"categoryName": "Avg Meeting Time",
			"value": "35 min",
		}, {
			"categoryName": "Total Transactions",
			"value": "2,335",
			
		},{
			"categoryName": "Total Amount",
			"value": "2,54,335",
		},{
			"categoryName": "$ per Transactions",
			"value": "60",
		}, {
			"categoryName": "Total Meeting",
			"value": "100",
		}, {
			"categoryName": "Avg Meeting Time",
			"value": "35 min",
		}, {
			"categoryName": "Total Transactions",
			"value": "2,335",
			
		},{
			"categoryName": "Total Amount",
			"value": "2,54,335",
		},{
			"categoryName": "$ per Transactions",
			"value": "60",
		}]
		this.dashboardSliderData = this.chunks(this.dashboardSliderData, 5);

    this.districtList = [
      { "item_id": 1, "item_text": 'District 1' },
      { "item_id": 2, "item_text": 'District 2' },
      { "item_id": 3, "item_text": 'District 3' },
      { "item_id": 4, "item_text": 'District 4' },
      { "item_id": 5, "item_text": 'District 5' }
    ];
    this.districtSelectedItems = [
      { "item_id": 4, "item_text": 'District 4' }
    ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 3,
      allowSearchFilter: false
    };

    this.storeList = [
      { "item_id": 1, "item_text": 'Store 1' },
      { "item_id": 2, "item_text": 'Store 2' },
      { "item_id": 3, "item_text": 'Store 3' },
      { "item_id": 4, "item_text": 'Store 4' },
      { "item_id": 5, "item_text": 'Store 5' }
    ];
    this.storeSelectedItems = [
      { "item_id": 3, "item_text": 'Store 3' }
    ];
	}

  isCardPopup:boolean = false;
  open(content:any, obj:any) {
    if(obj.categoryName == "Total Amount"){
      this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
        this.selectTab ='Summary';
        this.isCardPopup = true;
      }, (reason) => {
        this.isCardPopup = false;
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

	chunks(array:any, size:any) {
		let results = [];
		results = [];
		while (array.length) {
		  results.push(array.splice(0, size));
		}
		return results;
	}

  selectedTab(tab:string){
    this.selectTab = tab;
  }

  isComparePopup:boolean = false;
  openCompare(content:any) {
    this.isComparePopup = false;
      this.modalService.open(content, { size:'lg', ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
        this.isComparePopup = true;
      }, (reason) => {
        this.isComparePopup = false;
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
  }

}
