import { Component, OnInit, Input, ElementRef,ViewEncapsulation } from '@angular/core';
import { EChartsOption } from 'echarts';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { IDropdownSettings } from 'ng-multiselect-dropdown';

@Component({
  selector: 'app-landing-page',
  templateUrl: './landing-page.component.html',
  styleUrls: ['./landing-page.component.scss'],
  encapsulation: ViewEncapsulation.None
})
export class LandingPageComponent implements OnInit {
  filterDataObj: any ="test"
  public dashboardSliderData: Array<any> = [];
  selectTab:string = "Summary";

  public closeResult: any;

  districtList: any = [];
  districtSelectedItems : any = [];
  dropdownSettings:IDropdownSettings = {};

  storeList: any = [];
  storeSelectedItems : any = [];

  maxDate= new Date();
  selectDate:any;
//   genderSelectedItems : any = [];
//   genderList: any = [{
//     "item_id": "male",
//     "item_text": "Male",
//   },
//   {
//     "item_id": "female",
//     "item_text": "Female",
//   }
//   ,
//   {
//     "item_id": "Other",
//     "item_text": "Other",
//   }
// ]
  
  
  ageSelectedItems : any = [];
  ageList: any = [{
    "item_id": "0-20",
    "item_text": "0-20",
  },
  {
    "item_id": "20-40",
    "item_text": "20-40",
  },
  {
    "item_id": "Above 40",
    "item_text": "Above 40",
  },
  {
    "item_id": "Unknown",
    "item_text": "Unknown",
  },];

  cardlist: any =[{
    "categoryName": "Total Meeting",
    "value": "100",
  }, {
    "categoryName": "Avg Meeting Time",
    "value": "35 min",
  }, {
    "categoryName": "Total Transactions",
    "value": "2,335",
    
  },{
    "categoryName": "Total Amount",
    "value": "2,54,335",
  },{
    "categoryName": "$ per Transactions",
    "value": "60",
  }];
  constructor(private modalService: NgbModal) { }

  ngOnInit(): void {
		this.dashboardSliderData = [{
			"categoryName": "Total Meeting",
			"value": "100",
      "icon" : "user"
		}, {
			"categoryName": "Avg Meeting Time",
			"value": "35 min",
      "icon" : "clock"
		}, {
			"categoryName": "Total Transactions",
			"value": "2,335",
      "icon" : "vector"
			
		},{
			"categoryName": "Total Amount",
			"value": "2,54,335",
      "icon" : "finance"
		},{
			"categoryName": "$ per Transactions",
			"value": "60",
      "icon" : "avg"
		}, {
      "categoryName": "Total Meeting",
			"value": "100",
      "icon" : "user"
		}, {
			"categoryName": "Avg Meeting Time",
			"value": "35 min",
      "icon" : "clock"
		}, {
			"categoryName": "Total Transactions",
			"value": "2,335",
      "icon" : "vector"
			
		},{
			"categoryName": "Total Amount",
			"value": "2,54,335",
      "icon" : "finance"
		},{
			"categoryName": "$ per Transactions",
			"value": "60",
      "icon" : "avg"
		}]
		this.dashboardSliderData = this.chunks(this.dashboardSliderData, 5);

    this.districtList = [
      { "item_id": 1, "item_text": 'District 1' },
      { "item_id": 2, "item_text": 'District 2' },
      { "item_id": 3, "item_text": 'District 3' },
      { "item_id": 4, "item_text": 'District 4' },
      { "item_id": 5, "item_text": 'District 5' }
    ];
    // this.districtSelectedItems = [
    //   { "item_id": 4, "item_text": 'District 4' }
    // ];
    this.dropdownSettings = {
      singleSelection: false,
      idField: 'item_id',
      textField: 'item_text',
      selectAllText: 'Select All',
      unSelectAllText: 'UnSelect All',
      itemsShowLimit: 1,
      allowSearchFilter: false,
     
    };

    

    this.storeList = [
      { "item_id": 1, "item_text": 'Store 1' },
      { "item_id": 2, "item_text": 'Store 2' },
      { "item_id": 3, "item_text": 'Store 3' },
      { "item_id": 4, "item_text": 'Store 4' },
      { "item_id": 5, "item_text": 'Store 5' }
    ];
    // this.storeSelectedItems = [
    //   { "item_id": 3, "item_text": 'Store 3' }

    this.lastYear();
    // ];
	}

  isCardPopup:boolean = false;
  open(content:any, obj:any) {
    if(obj.categoryName == "Total Amount"){
      this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
        this.selectTab ='Summary';
        this.isCardPopup = true;
      }, (reason) => {
        this.isCardPopup = false;
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
    }
  }

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }

	chunks(array:any, size:any) {
		let results = [];
		results = [];
		while (array.length) {
		  results.push(array.splice(0, size));
		}
		return results;
	}

  selectedTab(tab:string){
    this.selectTab = tab;
  }

  isComparePopup:boolean = false;
  openCompare(content:any) {
    this.isComparePopup = false;
      this.modalService.open(content, { size:'lg', ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
        this.isComparePopup = true;
      }, (reason) => {
        this.isComparePopup = false;
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
  }

  isCompareDatePopup:boolean = false;
  openCompareDate(content:any) {
    this.isComparePopup = false;
      this.modalService.open(content, { size:'sm', ariaLabelledBy: 'modal-basic-title' }).result.then((result) => {
        this.closeResult = `Closed with: ${result}`;
        this.isCompareDatePopup = true;
      }, (reason) => {
        this.isCompareDatePopup = false;
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });
  }
dateRange:any;
  lastYear(){
 var LastYear = new Date();
 LastYear.setDate( LastYear.getDate() - 365 );
 console.log( LastYear );
  }

  selectDateHandler(reference:any, modelData:string){
    if(modelData=="custom"){
      this.openCompareDate(reference)
    }
  }

}
