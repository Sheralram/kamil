import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { first } from 'rxjs/operators';
import { HttpService } from './http.service';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  constructor(private http: HttpService) { }

  loginUser(data: any) {
    const url = `/authenticate`;
    return this.http.post(url, data)
  }

  getToken() {
    return localStorage.getItem("access_token");
  }

  // userRegister(data:any) {
  //   const url = `/register/user`;
  //   return this.http.post(url, data)
  // }

  // forgetPassword(data:any) {
  //   const url = `/forgotPassword`;
  //   return this.http.post(url, data)
  // }

  // changePassword(data: any) {
  //   const url = `/changePassword`;
  //   return this.http.post(url, data)
  // }

  logout(data: any) {
    const url = `/logout`;
    return this.http.post(url, data)
  }

 
 


  

 
}

